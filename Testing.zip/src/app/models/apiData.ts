export interface Data{
    country:string;
    countryabbreviation:string;
    postcode:string;
    places:Places[];
}
export interface Places{
    latitude:string;
    longitude:string;
    placename:string;
    state:string;
    stateabbreviation:string;
}